import { LightningElement, api,track, wire} from 'lwc';
import { ShowToastEvent} from 'lightning/platformShowToastEvent';
import SHOW_HEALTH_BASED_ON_TOTAL from '@salesforce/apex/StudentHealthController.showStudentHealthBasedOnTotal';
import { getRecord } from 'lightning/uiRecordApi';
import RoleName from '@salesforce/schema/User.UserRole.Name';
import Id from '@salesforce/user/Id'; 

export default class StudentHealth extends LightningElement {
    isLoading = false;
    currentAcademicYear = '';
    @api getValueFromHealthReport;
    @track parentHealthTotalRowID = '';
    @track healthThirdTableForNW = false;
    @track healthThirdTableForOW = false;
    @track healthThirdTableForUW = false;
    @track healthThirdTableForOB = false;
     getValueToDisplayFromHealthReport = '';
     isRecordListEmpty = false;

    //--- pagination Variable start ---
    @track recordEndTotal = 0;
    @track recordStartTotal = 0;
    @track pageNumberTotal = 1;
    @track totalRecordsTotal = 0;
    @track totalPagesTotal = 0;
    @track errorTotal = null;
    @track pageSizeTotal = 2;
    @track isPrevTotal = true;
    @track isNextTotal = true;
    @track showHealthBasesOnTotalList;
    //--- pagination Variable end ---

    userRoleName;
    @wire(getRecord, { recordId: Id, fields: [RoleName] })
    userDetails({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            console.log('data'+JSON.stringify(data));
            if (data.fields.UserRole.value != null) {
                this.userRoleName = data.fields.UserRole.value.fields.Name.value;
                console.log('user role name ',this.userRoleName);
            }
           
        }
    }

    headers = [
        "Classes",
        "Normal Weight",
        "Obese",
        "Over Weight",
        "Under Weight"
        ];

    connectedCallback(){
        this.showHealthReportBasesOnTotal();
    }

    @api refreshComponent(event) {
        try{
            console.log('Parent Id in refresh: ' + this.getValueFromHealthReport);
            this.showHealthReportBasesOnTotal();
            this.healthThirdTableForNW = false;
            this.healthThirdTableForOW = false;
            this.healthThirdTableForUW = false;
            this.healthThirdTableForOB = false;
        }catch(error)
        {
            console.log(error.message);
        }
    }

    downloadStudentHealthTotalDetails()
    {
        try{
            this.exportCSVFile(this.headers, this.showHealthBasesOnTotalList, "Student Health Based On Total detail");
        }catch(err)
        {
            console.log(err.message);
        }
    }

    exportCSVFile(headers, totalData, fileTitle){

        console.log('preparing data');
     // Prepare a html table
     let doc = '<table>';
     // Add styles for the table
     doc += '<style>';
     doc += 'table, th, td {';
     doc += '    text-align: center;';
     doc += '    border: 1px solid black;';
     doc += '    border-collapse: collapse;';
     doc += '}';
     doc += '</style>';
    
     // Add all the Table Headers
     doc += '<tr>';
     headers.forEach(element => {
         doc += '<th>' + element + '</th>'
     });
     doc += '</tr>';
     // Add the data rows
     totalData.forEach(record => {
         doc += '<tr>';
         doc += '<td>' + record.classes + '</td>';
         doc += '<td>' + record.normalWeight + '</td>';
         doc += '<td>' + record.obese + '</td>';
         doc += '<td>' + record.overWeight + '</td>';
         doc += '<td>' + record.underWeight + '</td>';
         doc += '</tr>';
     });
     doc += '</table>';
    
     var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
     let downloadElement = document.createElement('a');
     downloadElement.href = element;
     downloadElement.target = '_self';
     // use .csv as extension on below line if you want to export data as csv
     downloadElement.download = fileTitle ? fileTitle+'.xls' :'export.xls';
    
     document.body.appendChild(downloadElement);
     downloadElement.click();
    }

    showToast(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }

    showHealthReportBasesOnTotal(){

        try{
        this.isLoading = true;
        console.log('Parent Id : ' + this.getValueFromHealthReport);
        this.getValueToDisplayFromHealthReport = this.getValueFromHealthReport.replace('_',' ');
        //this.showHealthList = {};
        SHOW_HEALTH_BASED_ON_TOTAL({
            parentID : this.getValueFromHealthReport,
            pageSize: this.pageSizeTotal, 
            pageNumber: this.pageNumberTotal
        }).then(result => {
                this.isLoading = false;
                if (result) {
                    var resultData = JSON.parse(result);
                    console.log('SHOW_HEALTH_BASED_ON_TOTAL Result   ', resultData);
                    this.recordEndTotal = resultData.recordEnd;
                    this.totalRecordsTotal = resultData.totalRecords;
                    this.recordStartTotal = resultData.recordStart;
                    this.showHealthBasesOnTotalList = resultData.reportWrapper;
                    this.pageNumberTotal = resultData.pageNumber;
                    this.totalPagesTotal = Math.ceil(resultData.totalRecords / this.pageSizeTotal);
                    this.isNextTotal = (this.pageNumberTotal == this.totalPagesTotal || this.totalPagesTotal == 0);
                    this.isPrevTotal = (this.pageNumberTotal == 1 || this.totalRecordsTotal < this.pageSizeTotal);
              
                    if(this.totalRecordsTotal == 0)
                    {
                        this.isRecordListEmpty = true;
                    }
                    else
                    {
                        this.isRecordListEmpty = false;
                    }
                }
                else
                {
                    this.showHealthBasesOnTotalList = undefined;
                    this.isRecordListEmpty = true;
                }
        })
        .catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });
    }catch(error)
    {
        console.log(error.message);
    }
}

    handleNormalWeight(event)
    {
        console.log('Handle Normal Weight : ' + event.target.text);
        if(event.target.text == 0)
        {
            this.showToast('Information','No Records To display','info');
            this.healthThirdTableForNW = false;
            this.healthThirdTableForOW = false;
            this.healthThirdTableForUW = false;
            this.healthThirdTableForOB = false;
            return;
        }

        this.parentHealthTotalRowID = event.currentTarget.dataset.value;
        console.log('this.parentHealthTotalRowID : ' + this.parentHealthTotalRowID);

        var childComponent = this.template.querySelector('c-student-health-report-based-on-normal-weight');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);

        this.healthThirdTableForNW = true;
        this.healthThirdTableForOB = false;
        this.healthThirdTableForOW = false;
        this.healthThirdTableForUW = false;
    }

    handleObese(event)
    {
        console.log('Handle Obese : ' + event.target.text);
        if(event.target.text == 0)
        {
            this.showToast('Information','No Records To display','info');
            this.healthThirdTableForNW = false;
            this.healthThirdTableForOW = false;
            this.healthThirdTableForUW = false;
            this.healthThirdTableForOB = false;
            return;
        }

        this.parentHealthTotalRowID = event.currentTarget.dataset.value;
        console.log('this.parentHealthTotalRowID : ' + this.parentHealthTotalRowID);

        var childComponent = this.template.querySelector('c-student-health-report-based-on-obese');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);

        this.healthThirdTableForOB = true;
        this.healthThirdTableForNW = false;
        this.healthThirdTableForOW = false;
        this.healthThirdTableForUW = false;
    }

    handleOverWeight(event)
    {
        console.log('Handle Over Weight : ' + event.target.text);
        if(event.target.text == 0)
        {
            this.showToast('Information','No Records To display','info');
            this.healthThirdTableForNW = false;
            this.healthThirdTableForOW = false;
            this.healthThirdTableForUW = false;
            this.healthThirdTableForOB = false;
            return;
        }

        this.parentHealthTotalRowID = event.currentTarget.dataset.value;
        console.log('this.parentHealthTotalRowID : ' + this.parentHealthTotalRowID);
        
        var childComponent = this.template.querySelector('c-student-health-report-based-on-over-weight');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
        
        this.healthThirdTableForOW = true;
        this.healthThirdTableForNW = false;
        this.healthThirdTableForUW = false;
        this.healthThirdTableForOB = false;
    }

    handleUnderWeight(event)
    {
        console.log('Handle Under Weight : ' + event.target.text);
        if(event.target.text == 0)
        {
            this.showToast('Information','No Records To display','info');
            this.healthThirdTableForNW = false;
            this.healthThirdTableForOW = false;
            this.healthThirdTableForUW = false;
            this.healthThirdTableForOB = false;
            return;
        }
        this.parentHealthTotalRowID = event.currentTarget.dataset.value;
        console.log('this.parentHealthTotalRowID : ' + this.parentHealthTotalRowID);
        
        var childComponent = this.template.querySelector('c-student-health-report-based-on-under-weight');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
        
        this.healthThirdTableForUW = true;
        this.healthThirdTableForNW = false;
        this.healthThirdTableForOW = false;
        this.healthThirdTableForOB = false;
    }

    /* Pagination methods start */
    handlePageNextActionTotal() {
        this.pageNumberTotal = this.pageNumberTotal + 1;
        this.showHealthReportBasesOnTotal();
    }

    handlePagePrevActionTotal() {
        this.pageNumberTotal = this.pageNumberTotal - 1;
        this.showHealthReportBasesOnTotal();
    }
    /* Pagination methods END */


    handleReset()
    {
        this.isLoading = false;
        this.parentHealthTotalRowID = '';
        this.healthThirdTableForNW = false;
        this.healthThirdTableForOW = false;
        this.healthThirdTableForUW = false;
        this.healthThirdTableForOB = false;
        this.getValueToDisplayFromHealthReport = '';


        this.recordEndTotal = 0;
        this.recordStartTotal = 0;
        this.pageNumberTotal = 1;
        this.totalRecordsTotal = 0;
        this.totalPagesTotal = 0;
        this.errorTotal = null;
        this.pageSizeTotal = 2;
        this.isPrevTotal = true;
        this.isNextTotal = true;
        this.showHealthBasesOnTotalList;
    }

}