import { LightningElement ,api, track,wire} from 'lwc';
import SHOW_HEALTH_BASED_ON_UNDER_WEIGHT from '@salesforce/apex/StudentHealthController.showStudentHealthBasedOnUnderWeight';
import GET_LATEST_ACADEMIC_YEAR from '@salesforce/apex/AcademicYearController.getAcademicYearInfo';
import GET_SCHOOL_ID from "@salesforce/apex/SubjectController.getSchoolID";
import { getRecord } from 'lightning/uiRecordApi';
import RoleName from '@salesforce/schema/User.UserRole.Name';
import Id from '@salesforce/user/Id'; 

export default class studentHealthReportBasedOnUnderWeight extends LightningElement {
    showHealthBasesOnNormalWeightList = {};
    getValueToDisplayFromHealthReport;
    isLoading = false;
    currentAcademicYear = '';
    @api getValueFromHealthTotalReport;
    @track parentHealthNormalWeightRowID = '';
    @track healthFourthTable = false;
    isRecordListEmpty = false;
     //--- pagination Variable start ---
     @track recordEndSel = 0;
     @track recordStartSel = 0;
     @track pageNumberSel = 1;
     @track totalRecordsSel = 0;
     @track totalPagesSel = 0;
     @track errorSel = null;
     @track pageSizeSel = 2;
     @track isPrevSel = true;
     @track isNextSel = true;
     @track showHealthBasesOnNormalWeightList;
     //--- pagination Variable end ---

     userRoleName;
    @wire(getRecord, { recordId: Id, fields: [RoleName] })
    userDetails({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            console.log('data'+JSON.stringify(data));
            if (data.fields.UserRole.value != null) {
                this.userRoleName = data.fields.UserRole.value.fields.Name.value;
                console.log('user role name ',this.userRoleName);
            }
           
        }
    }
 
     headers = [
         "Class",
         "Name"
         ];

         headersForExcel = [
        //"Month",
         "Class",
         "Name"
         ]
 
  
    connectedCallback(){
        this.showHealthReportBasesOnNormalWeight();
    }

    getSchoolID()
    {
      this.isLoading = true;
      GET_SCHOOL_ID().then((result) => {
        this.isLoading = false;
        console.log("GET_SCHOOL_ID",result);
        this.schoolId = result;
        this.getAcademicYearOptions();
      }).catch((error) => {
        this.isLoading = false;
        console.error("Error: ", error);
        this.showToast("Error", error.body.message, "info");
      });
    }

    getAcademicYearOptions()
    {
        GET_LATEST_ACADEMIC_YEAR({
            schoolId : this.schoolId
        }).then(result => {
            this.isLoading = false;
            console.log('GET_LATEST_ACADEMIC_YEAR for subject Result   ', JSON.parse(result));
            this.currentAcademicYear =  JSON.parse(result).currentAcademicYear;
            this.showHealthReportBasesOnNormalWeight();
        })
        .catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'info');
        });
    }


    downloadStudentHealthUWSelDetails()
    {
        try{
            this.exportCSVFile(this.headersForExcel, this.showHealthBasesOnNormalWeightList, "Student Health Based On Under Weight detail");
        }catch(err)
        {
            console.log(err.message);
        }
    }

    exportCSVFile(headers, totalData, fileTitle){

        console.log('preparing data');
     // Prepare a html table
     let doc = '<table>';
     // Add styles for the table
     doc += '<style>';
     doc += 'table, th, td {';
     doc += '    text-align: center;';
     doc += '    border: 1px solid black;';
     doc += '    border-collapse: collapse;';
     doc += '}';
     doc += '</style>';
    
     // Add all the Table Headers
     doc += '<tr>';
     headers.forEach(element => {
         doc += '<th>' + element + '</th>'
     });
     doc += '</tr>';
     // Add the data rows
     totalData.forEach(record => {
         doc += '<tr>';
       //  doc += '<td>' + record.month + '</td>';
         doc += '<td>' + record.className + '</td>';
         doc += '<td>' + record.name + '</td>';
         doc += '</tr>';
     });
     doc += '</table>';
    
     var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
     let downloadElement = document.createElement('a');
     downloadElement.href = element;
     downloadElement.target = '_self';
     // use .csv as extension on below line if you want to export data as csv
     downloadElement.download = fileTitle ? fileTitle+'.xls' :'export.xls';
    
     document.body.appendChild(downloadElement);
     downloadElement.click();
    }


    @api refreshComponent(event) {
        console.log('Parent Id in refresh: ' + this.getValueFromHealthTotalReport);
        this.showHealthReportBasesOnNormalWeight();
        this.healthFourthTable = false;
    }

    showHealthReportBasesOnNormalWeight(){
        this.isLoading = true;
        //this.showHealthList = {};
        console.log('getValueFromHealthTotalReport : ' + this.getValueFromHealthTotalReport);
        this.getValueToDisplayFromHealthReport = this.getValueFromHealthTotalReport.replace('_UW', '').replaceAll('_',' ');
        SHOW_HEALTH_BASED_ON_UNDER_WEIGHT({
            parentTotalId : this.getValueFromHealthTotalReport,
            pageSize: this.pageSizeSel, 
            pageNumber: this.pageNumberSel
        }).then(result => {
                this.isLoading = false;
                if (result) {
                    var resultData = JSON.parse(result);
                    console.log('SHOW_HEALTH_BASED_ON_UNDER_WEIGHT Result   ', resultData);
                    this.recordEndSel = resultData.recordEnd;
                    this.totalRecordsSel = resultData.totalRecords;
                    this.recordStartSel = resultData.recordStart;
                    this.showHealthBasesOnNormalWeightList = resultData.reportWrapper;
                    this.pageNumberSel = resultData.pageNumber;
                    this.totalPagesSel = Math.ceil(resultData.totalRecords / this.pageSizeSel);
                    this.isNextSel = (this.pageNumberSel == this.totalPagesSel || this.totalPagesSel == 0);
                    this.isPrevSel = (this.pageNumberSel == 1 || this.totalRecordsSel < this.pageSizeSel);

                    if(this.totalRecordsSel == 0)
                    {
                        this.isRecordListEmpty = true;
                    }
                    else
                    {
                        this.isRecordListEmpty = false;
                    }
                }
            })
        .catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });
    }

 /* Pagination methods start */
 handlePageNextActionSel() {
    this.pageNumberSel = this.pageNumberSel + 1;
    this.showHealthReportBasesOnNormalWeight();
}

handlePagePrevActionSel() {
    this.pageNumberSel = this.pageNumberSel - 1;
    this.showHealthReportBasesOnNormalWeight();
}
/* Pagination methods END */

    handleNormalWeight(event)
    {
        this.parentHealthNormalWeightRowID = event.currentTarget.dataset.value;
        console.log('this.parentHealthNormalWeightRowID : ' + this.parentHealthNormalWeightRowID);
        this.healthFourthTable = true;

        var childComponent = this.template.querySelector('c-student-health-report-based-on-name');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    handleReset()
    {
        this.showHealthBasesOnNormalWeightList = {};
        this.isLoading = false;
        this.parentHealthNormalWeightRowID = '';
        this.healthFourthTable = false;
        this.recordEndSel = 0;
        this.recordStartSel = 0;
        this.pageNumberSel = 1;
        this.totalRecordsSel = 0;
        this.totalPagesSel = 0;
        this.errorSel = null;
        this.pageSizeSel = 2;
        this.isPrevSel = true;
        this.isNextSel = true;
        this.showHealthBasesOnNormalWeightList;
    }

}