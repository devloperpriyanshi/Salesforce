import { LightningElement, api,wire} from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import GET_MID_DAY_DETAIL from '@salesforce/apex/MidDayMealReportController.getMidDayMealDetailReport';
import GET_CURR_SYMBOL from '@salesforce/apex/MidDayMealReportController.getCurrencySymbol';
import { getRecord } from 'lightning/uiRecordApi';
import RoleName from '@salesforce/schema/User.UserRole.Name';
import Id from '@salesforce/user/Id'; 

export default class MidDaymealReportDetail extends LightningElement {

    midDayMealDetailsList;
    isLoading = false;
    currSymbol;
    @api getValueFromParentReport;
    isRecordListEmpty = false;
    getValueToDisplayFromMDMReport = '';
    userRoleName;
    @wire(getRecord, { recordId: Id, fields: [RoleName] })
    userDetails({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            console.log('data'+JSON.stringify(data));
            if (data.fields.UserRole.value != null) {
                this.userRoleName = data.fields.UserRole.value.fields.Name.value;
                console.log('user role name ',this.userRoleName);
            }
           
        }
    }

    headers = [
        "School",
        "Month( For that month)",
        "Per Child Cost Enrollment",
        "Per Child Cost-Food",
        "Per Child Cost Management- Fuel",
        "Total Per Child Cost Management",
        "Per Child Cost"
    ]

    connectedCallback()
    {
        GET_CURR_SYMBOL().then(result => {
            console.log('result --> ' + JSON.stringify(result));
            this.currSymbol = result;
            console.log('GET_CURR_SYMBOL --> '+ this.currSymbol);
        }).catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });

        this.fetchMidDayMealDataDetail();
    }

    @api refreshComponent(event) {
        console.log('Parent Id in refresh: ' + this.getValueFromParentReport);
        this.fetchMidDayMealDataDetail();
    }

    fetchMidDayMealDataDetail()
    {
        this.isLoading = true;

        GET_MID_DAY_DETAIL({
            parentID : this.getValueFromParentReport
        })
        .then(result => {
            this.isLoading = false;
            console.log('result --> ' + JSON.stringify(result));
            this.midDayMealDetailsList = result;

            this.getValueToDisplayFromMDMReport = this.midDayMealDetailsList[0].schoolName + ' ' + this.midDayMealDetailsList[0].month;
            console.log('GET_MID_DAY_DETAIL --> '+ this.midDayMealDetailsList);

            if(this.midDayMealDetailsList.length > 0)
            {
                this.isRecordListEmpty = false;
            }
            else
            {
                this.isRecordListEmpty = true;
            }

        }).catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });
    }

    downloadMidDayMealReportDetail()
    {
        try{
            this.exportCSVFile(this.headers, this.midDayMealDetailsList, "Mid Day Meal Report detail");
        }catch(err)
        {
            console.log(err.message);
        }
    }
    
     exportCSVFile(headers, totalData, fileTitle){
    
        console.log('preparing data');
     // Prepare a html table
     let doc = '<table>';
     // Add styles for the table
     doc += '<style>';
     doc += 'table, th, td {';
     doc += '    border: 1px solid black;';
     doc += '    border-collapse: collapse;';
     doc += '}';
     doc += '</style>';
    
     // Add all the Table Headers
     doc += '<tr>';
     headers.forEach(element => {
         doc += '<th>' + element + '</th>'
     });
     doc += '</tr>';
     // Add the data rows
     totalData.forEach(record => {
         doc += '<tr>';
         doc += '<td>' + record.schoolName + '</td>';
         doc += '<td>' + record.month + '</td>';
         doc += '<td>' + this.currSymbol + record.perChildCostEnrollment + '</td>';
         doc += '<td>' + this.currSymbol + record.perChildCostFood + '</td>';
         doc += '<td>' + this.currSymbol + record.perChildCostFuel + '</td>';
         doc += '<td>' + this.currSymbol + record.perchildCostManagement + '</td>';
         doc += '<td>' + this.currSymbol + record.perChildCost + '</td>';
         doc += '</tr>';
     });
     doc += '</table>';
    
     let element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
     let downloadElement = document.createElement('a');
     downloadElement.href = element;
     downloadElement.target = '_self';
     // use .csv as extension on below line if you want to export data as csv
     downloadElement.download = fileTitle ? fileTitle+'.xls' :'export.xls';
    
     document.body.appendChild(downloadElement);
     downloadElement.click();
    }
    
    showToast(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }
 
    handleReset()
    {
        this.midDayMealDetailsList = {};
        this.isLoading = false;
        this.currSymbol = '';
        this.isRecordListEmpty = false;
        this.getValueToDisplayFromMDMReport = '';
    }
}