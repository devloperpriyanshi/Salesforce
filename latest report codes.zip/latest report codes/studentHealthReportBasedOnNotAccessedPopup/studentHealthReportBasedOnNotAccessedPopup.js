import { LightningElement, api } from "lwc";
import SHOW_HEALTH_BASED_ON_NA_POPUP from "@salesforce/apex/StudentHealthController.showStudentHealthBasedOnNAPopup";
import GET_LATEST_ACADEMIC_YEAR from "@salesforce/apex/AcademicYearController.getAcademicYearInfo";
import GET_SCHOOL_ID from "@salesforce/apex/SubjectController.getSchoolID";

export default class StudentHealthReportBasedOnNotAccessedPopup extends LightningElement {
  isLoading = false;
  isShowModel = true;
  @api showModel = false;
  @api getValueFromHealthReport;
  showHealthBasesOnNAPopup;
  headingToDisplayOnPopup = "";
  currentAcademicYear = "";

  headers = [
    //"Month", 
    "Class", 
    "Name"];

  connectedCallback() {
    this.showHealthBasesOnObese();
  }

  getSchoolID() {
    this.isLoading = true;
    GET_SCHOOL_ID()
      .then((result) => {
        this.isLoading = false;
        console.log("GET_SCHOOL_ID", result);
        this.schoolId = result;
        this.getAcademicYearOptions();
      })
      .catch((error) => {
        this.isLoading = false;
        console.error("Error: ", error);
        this.showToast("Error", error.body.message, "info");
      });
  }

  getAcademicYearOptions() {
    GET_LATEST_ACADEMIC_YEAR({
      schoolId: this.schoolId
    })
      .then((result) => {
        this.isLoading = false;
        console.log(
          "GET_LATEST_ACADEMIC_YEAR for subject Result   ",
          JSON.parse(result)
        );
        this.currentAcademicYear = JSON.parse(result).currentAcademicYear;
        this.showHealthBasesOnObese();
      })
      .catch((error) => {
        this.isLoading = false;
        console.error("Error: ", error);
        this.showToast("Error", error.body.message, "info");
      });
  }

  @api refreshComponent(event) {
    this.showHealthBasesOnObese();
  }

  showHealthBasesOnObese() {
    this.isLoading = true;
    let parentID = this.getValueFromHealthReport;
    this.headingToDisplayOnPopup = parentID.replaceAll("_", " ");
    console.log(parentID);
    this.isShowModel = true;
    SHOW_HEALTH_BASED_ON_NA_POPUP({
      parentId: this.getValueFromHealthReport
    })
      .then((result) => {
        this.isLoading = false;

        let resultData = JSON.parse(result);

        console.log("SHOW_HEALTH_BASED_ON_NA_POPUP Result   ", resultData);

        this.showHealthBasesOnNAPopup = resultData;
      })
      .catch((error) => {
        this.isLoading = false;
        console.error("Error: ", error);
        this.showToast("Error", error.body.message, "error");
      });
  }

  downloadNAPopupDetails() {
    try {
      this.exportCSVFile(
        this.headers,
        this.showHealthBasesOnNAPopup,
        "Student Health " + this.headingToDisplayOnPopup
      );
    } catch (err) {
      console.log(err.message);
    }
  }

  exportCSVFile(headers, totalData, fileTitle) {
    console.log("preparing data");
    // Prepare a html table
    let doc = "<table>";
    // Add styles for the table
    doc += "<style>";
    doc += "table, th, td {";
    doc += '    text-align: center;';
    doc += "    border: 1px solid black;";
    doc += "    border-collapse: collapse;";
    doc += "}";
    doc += "</style>";

    // Add all the Table Headers
    doc += "<tr>";
    headers.forEach((element) => {
      doc += "<th>" + element + "</th>";
    });
    doc += "</tr>";
    // Add the data rows
    totalData.forEach((record) => {
      doc += "<tr>";
      //doc += "<td>" + record.month + "</td>";
      doc += "<td>" + record.className + "</td>";
      doc += "<td>" + record.name + "</td>";
      doc += "</tr>";
    });
    doc += "</table>";

    var element = "data:application/vnd.ms-excel," + encodeURIComponent(doc);
    let downloadElement = document.createElement("a");
    downloadElement.href = element;
    downloadElement.target = "_self";
    // use .csv as extension on below line if you want to export data as csv
    downloadElement.download = fileTitle ? fileTitle + ".xls" : "export.xls";

    document.body.appendChild(downloadElement);
    downloadElement.click();
  }

  hideModalBox() {
    this.isShowModel = false;
  }

  handleReset() {
    this.isLoading = false;
    //  this.isShowModel = false;
    this.showHealthBasesOnNAPopup = undefined;
    this.headingToDisplayOnPopup = "";
  }
}