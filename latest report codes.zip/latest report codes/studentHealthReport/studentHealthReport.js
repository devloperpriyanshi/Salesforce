import { LightningElement, track, wire} from 'lwc';
import GET_LATEST_ACADEMIC_YEAR from '@salesforce/apex/AcademicYearController.getAcademicYearInfo';
import SHOW_HEALTH_INFO from '@salesforce/apex/StudentHealthController.showStudentHealth';
import GET_SCHOOL_ID from "@salesforce/apex/SubjectController.getSchoolID";

import { getRecord } from 'lightning/uiRecordApi';
import RoleName from '@salesforce/schema/User.UserRole.Name';
import Id from '@salesforce/user/Id';

export default class StudentHealth extends LightningElement {
    isLoading = false;

    showObesePopup = false;
    showNWPopup = false;
    showNAPopup = false;
    showOWPopup = false;
    showUWPopup = false;
    
    userRoleName;
    @wire(getRecord, { recordId: Id, fields: [RoleName] })
    userDetails({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            console.log('data'+JSON.stringify(data));
            if (data.fields.UserRole.value != null) {
                this.userRoleName = data.fields.UserRole.value.fields.Name.value;
                console.log('user role name ',this.userRoleName);
            }
           
        }
    }
    @track parentHealthRowIDForNA;
    @track parentHealthRowIDForNB;
    @track parentHealthRowIDForObese;
    @track parentHealthRowIDForOW;
    @track parentHealthRowIDForUW;

    schoolId;
    @track parentHealthRowID;
    @track healthSecondTable = false;
    currentAcademicYear = '';
    academicYearOptions = [];
    isRecordListEmpty = false;

    //--- pagination Variable start ---
    @track recordEnd = 0;
    @track recordStart = 0;
    @track pageNumber = 1;
    @track totalRecords = 0;
    @track totalPages = 0;
    @track error = null;
    @track pageSize = 2;
    @track isPrev = true;
    @track isNext = true;
    @track showHealthList; // accountRecList
    //--- pagination Variable end ---

    headers = [
        "School",
        // "Month",
        "Normal Weight",
        "Obese",
        "Over Weight",
        "Under Weight",
        "Not Accessed",
        "Total"
    ];

    // Pagination
    connectedCallback(){
        this.showHealthReport();
    }

    getSchoolID()
    {
      this.isLoading = true;
      GET_SCHOOL_ID().then((result) => {
        this.isLoading = false;
        console.log("GET_SCHOOL_ID",result);
        this.schoolId = result;
        this.getAcademicYearOptions();
      }).catch((error) => {
        this.isLoading = false;
        console.error("Error: ", error);
        this.showToast("Error", error.body.message, "info");
      });
    }

    getAcademicYearOptions()
    {
        GET_LATEST_ACADEMIC_YEAR({
            schoolId : this.schoolId
        }).then(result => {
            this.isLoading = false;
            console.log('GET_LATEST_ACADEMIC_YEAR for subject Result   ', JSON.parse(result));
            this.currentAcademicYear =  JSON.parse(result).currentAcademicYear;

            /* let data = JSON.parse(result); 
            if(data){
                this.academicYearOptions.push({ label: data.currentAcademicYear, value: data.currentAcademicYear });
                this.academicYearOptions.push({ label: data.nextAcademicYear, value: data.nextAcademicYear });
            }
            console.log('Academic Years : ' + JSON.stringify(this.academicYearOptions));
            this.academicYearOptions = JSON.parse(JSON.stringify(this.academicYearOptions)); */
            this.showHealthReport();
        })
        .catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'info');
        });
    }

    handleAcademicYearChange(event) {
        this.currentAcademicYear = event.detail.value;
        this.healthSecondTable = false;

     if (this.currentAcademicYear != null) {
        this.isLoading = true;
        this.showHealthReport();
    }
}

downloadStudentHealthDetails()
{
    try{
        this.exportCSVFile(this.headers, this.showHealthList, "Student Health detail");
    }catch(err)
    {
        console.log(err.message);
    }
}

 exportCSVFile(headers, totalData, fileTitle){

    console.log('preparing data');
 // Prepare a html table
 let doc = '<table>';
 // Add styles for the table
 doc += '<style>';
 doc += 'table, th, td {';
 doc += '    text-align: center;';
 doc += '    border: 1px solid black;';
 doc += '    border-collapse: collapse;';
 doc += '}';
 doc += '</style>';

 // Add all the Table Headers
 doc += '<tr>';
 headers.forEach(element => {
     doc += '<th>' + element + '</th>'
 });
 doc += '</tr>';
 // Add the data rows
 totalData.forEach(record => {
     doc += '<tr>';
     doc += '<td>' + record.school + '</td>';
    //  doc += '<td>' + record.month + '</td>';
     doc += '<td>' + record.normalWeight + '</td>';
     doc += '<td>' + record.obese + '</td>';
     doc += '<td>' + record.overWeight + '</td>';
     doc += '<td>' + record.underWeight + '</td>';
     doc += '<td>' + record.notAccessed + '</td>';
     doc += '<td>' + record.total + '</td>';
     doc += '</tr>';
 });
 doc += '</table>';

 
 var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
 let downloadElement = document.createElement('a');
 downloadElement.href = element;
 downloadElement.target = '_self';
 // use .csv as extension on below line if you want to export data as csv
 downloadElement.download = fileTitle ? fileTitle+'.xls' :'export.xls';

 document.body.appendChild(downloadElement);
 downloadElement.click();
}
    showHealthReport(){
        this.isLoading = true;
        SHOW_HEALTH_INFO({
            pageSize: this.pageSize, 
            pageNumber: this.pageNumber
        }).then(result => {
                this.isLoading = false;

                console.log('SHOW_HEALTH_INFO Result  initial ', result);

                if (result) {
                    var resultData = JSON.parse(result);
                    console.log('SHOW_HEALTH_INFO Result   ', resultData);
                    this.recordEnd = resultData.recordEnd;
                    this.totalRecords = resultData.totalRecords;
                    this.recordStart = resultData.recordStart;
                    this.showHealthList = resultData.reportWrapper;
                    this.pageNumber = resultData.pageNumber;
                    this.totalPages = Math.ceil(resultData.totalRecords / this.pageSize);
                    this.isNext = (this.pageNumber == this.totalPages || this.totalPages == 0);
                    this.isPrev = (this.pageNumber == 1 || this.totalRecords < this.pageSize);

                if(this.totalRecords == 0)
                {
                    this.isRecordListEmpty = true;
                }
                else
                {
                    this.isRecordListEmpty = false;
                }
            }
            else
            {
                this.showHealthList = undefined;
                this.isRecordListEmpty = true;
            }
        })
        .catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });
    }

    handleTotal(event)
    {
        this.healthSecondTable = true;
        this.parentHealthRowID = event.target.dataset.id;
        console.log('this.parentHealthRowID : ' + this.parentHealthRowID);

        let childComponent = this.template.querySelector('c-student-health-report-based-on-total');
        
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    /* Pagination methods start */
    handlePageNextAction() {
        this.pageNumber = this.pageNumber + 1;
        this.showHealthReport();
    }

    handlePagePrevAction() {
        this.pageNumber = this.pageNumber - 1;
        this.showHealthReport();
    }

    /* Pagination methods END */

    handleObesePopup(event)
    {
        this.showObesePopup = true;
        this.parentHealthRowIDForObese = event.target.dataset.id;
        console.log('this.parentHealthRowID for obese : ' + this.parentHealthRowIDForObese);

        let childComponent = this.template.querySelector('c-student-health-report-based-on-obese-popup');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    handleNWPopup(event)
    {
        this.showNWPopup = true;
        this.parentHealthRowIDForNB = event.target.dataset.id;
        console.log('this.parentHealthRowID for NB : ' + this.parentHealthRowIDForNB);

        let childComponent = this.template.querySelector('c-student-health-report-based-on-normal-weight-popup');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    handleNAPopup(event)
    {
        this.showNAPopup = true;
        this.parentHealthRowIDForNA = event.target.dataset.id;
        console.log('this.parentHealthRowID for NA : ' + this.parentHealthRowIDForNA);

        let childComponent = this.template.querySelector('c-student-health-report-based-on-not-accessed-popup');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    handleOWPopup(event)
    {
        this.showOWPopup = true;
        this.parentHealthRowIDForOW = event.target.dataset.id;
        console.log('this.parentHealthRowID for OW : ' + this.parentHealthRowIDForOW);

        let childComponent = this.template.querySelector('c-student-health-report-based-on-over-weight-popup');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    handleUWPopup(event)
    {
        this.showUWPopup = true;
        this.parentHealthRowIDForUW = event.target.dataset.id;
        console.log('this.parentHealthRowID for UW : ' + this.parentHealthRowIDForUW);

        let childComponent = this.template.querySelector('c-student-health-report-based-on-under-weight-popup');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    handleReset()
    {
        this.showObesePopup = false;
        this.showNWPopup = false;
        this.showOWPopup = false;
        this.showUWPopup = false;


        this.isLoading = false;
        this.parentHealthRowID = '';
        this.healthSecondTable = false;
        this.currentAcademicYear = '';
        this.isRecordListEmpty = false;

        this.recordEnd = 0;
        this.recordStart = 0;
        this.pageNumber = 1;
        this.totalRecords = 0;
        this.totalPages = 0;
        this.error = null;
        this.pageSize = 2;
        this.isPrev = true;
        this.isNext = true;
        this.showHealthList = undefined;
    }

}