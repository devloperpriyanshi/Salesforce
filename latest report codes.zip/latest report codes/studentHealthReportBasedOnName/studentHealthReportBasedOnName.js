import { LightningElement, api , track, wire} from 'lwc';
import SHOW_HEALTH_BASED_ON_NAME from '@salesforce/apex/StudentHealthController.showStudentHealthBasedOnName';
import GET_LATEST_ACADEMIC_YEAR from '@salesforce/apex/AcademicYearController.getAcademicYearInfo';
import GET_SCHOOL_ID from "@salesforce/apex/SubjectController.getSchoolID";
import { getRecord } from 'lightning/uiRecordApi';
import RoleName from '@salesforce/schema/User.UserRole.Name';
import Id from '@salesforce/user/Id'; 

export default class StudentHealth extends LightningElement {
    isLoading = false;
    currentAcademicYear = '';
    getValueToDisplayFromHealthReport;
    @api getValueFromHealthNormalWeightReport;
    isRecordListEmpty = false;
     //--- pagination Variable start ---
     @track recordEndName = 0;
     @track recordStartName = 0;
     @track pageNumberName = 1;
     @track totalRecordsName = 0;
     @track totalPagesName = 0;
     @track errorName = null;
     @track pageSizeName = 2;
     @track isPrevName = true;
     @track isNextName = true;
     @track showHealthBasesOnNameList;
     //--- pagination Variable end ---
     userRoleName;
    @wire(getRecord, { recordId: Id, fields: [RoleName] })
    userDetails({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            console.log('data'+JSON.stringify(data));
            if (data.fields.UserRole.value != null) {
                this.userRoleName = data.fields.UserRole.value.fields.Name.value;
                console.log('user role name ',this.userRoleName);
            }
           
        }
    }
 
     headers = [
         
         "Name",
         "Height (centimetre)",
         "Weight (Kgs)",
         "BMI Status",
         "Iron Deficiency",
         "Anaemia",
         "Severly Malnourished",
         "Referrals",
         "Remarks"
         ];

         headersForExcel = [
            "Month",
            "Name",
            "Height (centimetre)",
            "Weight (Kgs)",
            "BMI Status",
            "Iron Deficiency",
            "Anaemia",
            "Severly Malnourished",
            "Referrals",
            "Remarks"
            ];

    connectedCallback(){
        this.showHealthReportBasesOnName();
    }

    getSchoolID()
    {
      this.isLoading = true;
      GET_SCHOOL_ID().then((result) => {
        this.isLoading = false;
        console.log("GET_SCHOOL_ID",result);
        this.schoolId = result;
        this.getAcademicYearOptions();
      }).catch((error) => {
        this.isLoading = false;
        console.error("Error: ", error);
        this.showToast("Error", error.body.message, "info");
      });
    }

    getAcademicYearOptions()
    {
        GET_LATEST_ACADEMIC_YEAR({
            schoolId : this.schoolId
        }).then(result => {
            this.isLoading = false;
            console.log('GET_LATEST_ACADEMIC_YEAR for subject Result   ', JSON.parse(result));
            this.currentAcademicYear =  JSON.parse(result).currentAcademicYear;

            this.showHealthReportBasesOnName();
        })
        .catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'info');
        });
    }

    @api refreshComponent(event) {
        console.log('Parent Id in refresh: ' + this.getValueFromHealthNormalWeightReport);
        this.showHealthReportBasesOnName();
    }

    downloadStudentHealthNameDetails()
    {
        try{
            this.exportCSVFile(this.headersForExcel, this.showHealthBasesOnNameList, "Student Health Based On Name detail");
        }catch(err)
        {
            console.log(err.message);
        }
    }

    exportCSVFile(headers, totalData, fileTitle){

        console.log('preparing data');
     // Prepare a html table
     let doc = '<table>';
     // Add styles for the table
     doc += '<style>';
     doc += 'table, th, td {';
     doc += '    text-align: center;';
     doc += '    border: 1px solid black;';
     doc += '    border-collapse: collapse;';
     doc += '}';
     doc += '</style>';
    
     // Add all the Table Headers
     doc += '<tr>';
     headers.forEach(element => {
         doc += '<th>' + element + '</th>'
     });
     doc += '</tr>';
     // Add the data rows
     totalData.forEach(record => {
         doc += '<tr>';
         doc += '<td>' + record.month + '</td>';
         doc += '<td>' + record.name + '</td>';
         doc += '<td>' + record.height + '</td>';
         doc += '<td>' + record.weight + '</td>';
         doc += '<td>' + record.bmiStatus + '</td>';
         doc += '<td>' + record.ironDeficiency + '</td>';
         doc += '<td>' + record.anaemia + '</td>';
         doc += '<td>' + record.severly + '</td>';
         doc += '<td>' + record.referrals + '</td>';
         doc += '<td>' + record.remarks + '</td>';
         doc += '</tr>';
     });
     doc += '</table>';
    
     var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
     let downloadElement = document.createElement('a');
     downloadElement.href = element;
     downloadElement.target = '_self';
     // use .csv as extension on below line if you want to export data as csv
     downloadElement.download = fileTitle ? fileTitle+'.xls' :'export.xls';
    
     document.body.appendChild(downloadElement);
     downloadElement.click();
    }

    showHealthReportBasesOnName(){
        this.isLoading = true;
        //this.showHealthList = {};

        console.log('getValueFromHealthNormalWeightReport : ' + this.getValueFromHealthNormalWeightReport);
        let parentKey = this.getValueFromHealthNormalWeightReport.split('_');
      //  this.getValueToDisplayFromHealthReport = parentKey[0] + ' ' + parentKey[1] + ' ' + parentKey[2];
      this.getValueToDisplayFromHealthReport = parentKey[0] + ' ' + parentKey[1];

        SHOW_HEALTH_BASED_ON_NAME({
            parentNormalWeightId: this.getValueFromHealthNormalWeightReport,
            pageSize: this.pageSizeName, 
            pageNumber: this.pageNumberName
        }).then(result => {
                this.isLoading = false;
                if (result) {
                    var resultData = JSON.parse(result);
                    console.log('SHOW_HEALTH_BASED_ON_NAME Result   ', resultData);
                    this.recordEndName = resultData.recordEnd;
                    this.totalRecordsName = resultData.totalRecords;
                    this.recordStartName = resultData.recordStart;
                    this.showHealthBasesOnNameList = resultData.reportWrapper;
                    this.pageNumberName = resultData.pageNumber;
                    this.totalPagesName = Math.ceil(resultData.totalRecords / this.pageSizeName);
                    this.isNextName = (this.pageNumberName == this.totalPagesName || this.totalPagesName == 0);
                    this.isPrevName = (this.pageNumberName == 1 || this.totalRecordsName < this.pageSizeName);
                  
                    if(this.totalRecordsName == 0)
                    {
                        this.isRecordListEmpty = true;
                    }
                    else
                    {
                        this.isRecordListEmpty = false;
                    }
                }
                })
        .catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });
    }

        /* Pagination methods start */
        handlePageNextActionName() {
            this.pageNumberName = this.pageNumberName + 1;
            this.showHealthReportBasesOnName();
        }
    
        handlePagePrevActionName() {
            this.pageNumberName = this.pageNumberName - 1;
            this.showHealthReportBasesOnName();
        }
        /* Pagination methods END */
    

    handleReset()
    {
        this.isLoading = false;

        this.recordEndName = 0;
        this.recordStartName = 0;
        this.pageNumberName = 1;
        this.totalRecordsName = 0;
        this.totalPagesName = 0;
        this.errorName = null;
        this.pageSizeName = 2;
        this.isPrevName = true;
        this.isNextName = true;
        this.showHealthBasesOnNameList;
      
    }

}