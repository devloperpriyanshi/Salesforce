import { LightningElement,track,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import GET_MID_DAY_DATA from '@salesforce/apex/MidDayMealReportController.getMidDayMealReport';
import GET_CURR_SYMBOL from '@salesforce/apex/MidDayMealReportController.getCurrencySymbol';
import { getRecord } from 'lightning/uiRecordApi';
import RoleName from '@salesforce/schema/User.UserRole.Name';
import Id from '@salesforce/user/Id'; 

export default class midDayMealReport extends LightningElement {

    schoolId;
    isLoading = false;
    @track currSymbol;
    @track parentID;
    @track childTable = false;
    academicYearOptions = [];

    isRecordListEmpty = false;
    userRoleName;
    @wire(getRecord, { recordId: Id, fields: [RoleName] })
    userDetails({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            console.log('data'+JSON.stringify(data));
            if (data.fields.UserRole.value != null) {
                this.userRoleName = data.fields.UserRole.value.fields.Name.value;
                console.log('user role name ',this.userRoleName);
            }
           
        }
    }

        //--- pagination Variable start ---
        @track recordEnd = 0;
        @track recordStart = 0;
        @track pageNumber = 1;
        @track totalRecords = 0;
        @track totalPages = 0;
        @track error = null;
        @track pageSize = 2;
        @track isPrev = true;
        @track isNext = true;
        @track midDayRecList; // accountRecList
        //--- pagination Variable end ---

    headers = [
        "School",
        "Start Month of AY",
        "Month 1",
        "Month 2",
        "Month 3",
        "Month 4",
        "Month 5",
        "Month 6",
        "Month 7",
        "Month 8",
        "Month 9",
        "Month 10",
        "Month 11",
        "Month 12"
    ];

    connectedCallback()
    {
       this.getData();
    }

    downloadMidDayMealReport()
{
    try{
        this.exportCSVFile(this.headers, this.midDayRecList, "Mid Day Meal Report detail");
    }catch(err)
    {
        console.log(err.message);
    }
}

 exportCSVFile(headers, totalData, fileTitle){

    console.log('preparing data');
 // Prepare a html table
 let doc = '<table>';
 // Add styles for the table
 doc += '<style>';
 doc += 'table, th, td {';
 doc += '    border: 1px solid black;';
 doc += '    border-collapse: collapse;';
 doc += '}';
 doc += '</style>';

 // Add all the Table Headers
 doc += '<tr>';
 headers.forEach(element => {
     doc += '<th>' + element + '</th>'
 });
 doc += '</tr>';
 // Add the data rows
 totalData.forEach(record => {
     doc += '<tr>';
     doc += '<td>' + record.schoolName + '</td>';
     doc += '<td>' + record.startingMonthOfAY + '</td>';
     doc += '<td>' + record.janPerChildCost + '</td>';
     doc += '<td>' + record.febPerChildCost + '</td>';
     doc += '<td>' + record.marchPerChildCost + '</td>';
     doc += '<td>' + record.aprilPerChildCost + '</td>';
     doc += '<td>' + record.mayPerChildCost + '</td>';
     doc += '<td>' + record.junePerChildCost + '</td>';
     doc += '<td>' + record.julyPerChildCost + '</td>';
     doc += '<td>' + record.augPerChildCost + '</td>';
     doc += '<td>' + record.septPerChildCost + '</td>';
     doc += '<td>' + record.octPerChildCost + '</td>';
     doc += '<td>' + record.novPerChildCost + '</td>';
     doc += '<td>' + record.decPerChildCost + '</td>';
     doc += '</tr>';
 });
 doc += '</table>';

 
 var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
 let downloadElement = document.createElement('a');
 downloadElement.href = element;
 downloadElement.target = '_self';
 // use .csv as extension on below line if you want to export data as csv
 downloadElement.download = fileTitle ? fileTitle+'.xls' :'export.xls';

 document.body.appendChild(downloadElement);
 downloadElement.click();
}

    getData()
    {
        GET_CURR_SYMBOL().then(result => {
            console.log('result --> ' + JSON.stringify(result));
            this.currSymbol = result;
            console.log('GET_CURR_SYMBOL --> '+ this.currSymbol);
        }).catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });

        GET_MID_DAY_DATA({
            pageSize: this.pageSize, 
            pageNumber: this.pageNumber
    })
        .then(result => {
            this.isLoading = false;
            console.log('Result --> ' + JSON.parse(result));
            if (result) {

                try{
                var resultData = JSON.parse(result);
                console.log('GET_MID_DAY_DATA Result   ', resultData);
                this.recordEnd = resultData.recordEnd;
                console.log('recordEnd Result   ', this.recordEnd);
                this.totalRecords = resultData.totalRecords;
                console.log('this.totalRecords Result   ', this.totalRecords);
                this.recordStart = resultData.recordStart;
                console.log('this.recordStart Result   ', this.recordStart);
                this.midDayRecList = resultData.reportWrapper;
                console.log('this.midDayRecList Result   ', this.midDayRecList);
                this.pageNumber = resultData.pageNumber;
                console.log('this.pageNumber Result   ', this.pageNumber);
                this.totalPages = Math.ceil(resultData.totalRecords / this.pageSize);
                console.log('this.totalPages Result   ', this.totalPages);
                this.isNext = (this.pageNumber == this.totalPages || this.totalPages == 0);
                console.log('this.isNext Result   ', this.isNext);
                this.isPrev = (this.pageNumber == 1 || this.totalRecords < this.pageSize);
                console.log('this.isPrev Result   ', this.isPrev);

            if(this.totalRecords == 0)
            {
                this.isRecordListEmpty = true;
            }
            else
            {
                this.isRecordListEmpty = false;
            }
        }catch(err){
            console.log(err.message);
        }
        }
        else
        {
            this.midDayRecList = undefined;
            this.isRecordListEmpty = true;
        }
        }).catch(error => {
            this.isLoading = false;
            console.error('Error: ' , error);
            this.showToast('Error',error.body.message,'error');
        });
    }

     /* Pagination methods start */
     handlePageNextAction() {
        this.pageNumber = this.pageNumber + 1;
        this.getData();
    }

    handlePagePrevAction() {
        this.pageNumber = this.pageNumber - 1;
        this.getData();
    }

    handleMidDayCost(event)
    {
       const costAndSymbol =  event.target.text;
       const cost = costAndSymbol.substring(1, costAndSymbol.length);

        if(cost == '0.0' || costAndSymbol == 'Not Available')
        {
            this.showToast('Information','No Records To display','info');
            this.childTable = false;
            return;
        }

        this.parentID = event.target.dataset.id;
        console.log('parent Id: ' + this.parentID);
        this.childTable = true;

        var childComponent = this.template.querySelector('c-mid-daymeal-report-detail');
        setTimeout(() => {
            childComponent.refreshComponent();
        }, 100);
    }

    showToast(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }

    handleReset()
    {
        this.isLoading = false;
        this.currSymbol = '';
        parentID = '';
        childTable = false;
        academicYearOptions = [];

        this.isRecordListEmpty = false;

        this.recordEnd = 0;
        this.recordStart = 0;
        this.pageNumber = 1;
        this.totalRecords = 0;
        this.totalPages = 0;
        this.error = null;
        this.pageSize = 2;
        this.isPrev = true;
        this.isNext = true;
        this.midDayRecList = undefined; 
    
    }
}